import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ColorCircleFrame {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Color Circle");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);

        // Circle icon with initial color red
        CircleIcon circle = new CircleIcon(50, Color.RED);
        JLabel label = new JLabel(circle);

        // Buttons
        JButton redButton = new JButton("Red");
        JButton greenButton = new JButton("Green");
        JButton blueButton = new JButton("Blue");

        // Button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(redButton);
        buttonPanel.add(greenButton);
        buttonPanel.add(blueButton);

        // Action listeners
        redButton.addActionListener(e -> {
            circle.setColor(Color.RED);
            label.repaint();
        });

        greenButton.addActionListener(e -> {
            circle.setColor(Color.GREEN);
            label.repaint();
        });

        blueButton.addActionListener(e -> {
            circle.setColor(Color.BLUE);
            label.repaint();
        });

        // Layout
        frame.setLayout(new BorderLayout());
        frame.add(label, BorderLayout.CENTER);
        frame.add(buttonPanel, BorderLayout.SOUTH);

        frame.setVisible(true);
    }
}

// Custom icon to draw a circle
class CircleIcon implements Icon {
    private int size;
    private Color color;

    public CircleIcon(int size, Color color) {
        this.size = size;
        this.color = color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public int getIconWidth() { return size; }
    public int getIconHeight() { return size; }

    public void paintIcon(Component c, Graphics g, int x, int y) {
        g.setColor(color);
        g.fillOval(x, y, size, size);
    }
}
