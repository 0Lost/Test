import java.util.ArrayList;


public interface FilterTest {

    public interface Filter {
        boolean accept(String x); 
    }

    public static String[] filter(String[] a, Filter f){
        ArrayList<String> result = new ArrayList<>();

        for (String s : a) {
            if (f.accept(s)) {
                result.add(s);
            }
        }

        return result.toArray(new String[0]);
    }

    public static void main(String[] args) {
        String[] words = { "baslisik", "hydra", "cathulu", "bat", "owl", "lion" };

        // Create a filter that accepts strings with at most 3 characters
        Filter shortWordsFilter = new Filter() {
            @Override
            public boolean accept(String x) {
                return x.length() <= 3;
            }
        };

        // Apply the filter
        String[] shortWords = filter(words, shortWordsFilter);

        // Print the results
        System.out.println("new Array after applying the filter: ");
        for (String word : shortWords) {
            System.out.println(word);
        }
    }

}
