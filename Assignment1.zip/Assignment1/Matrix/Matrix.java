public class Matrix{
    private double[][] data;
    private int row; 
    private int column;


    // Constructor
    public Matrix(int rows, int cols){
        this.row = rows; 
        this.column = cols; 
        this.data = new double[rows][cols];
    }

    // Getters and setters
    public double getElement(int rows, int cols){
        if(rows < 0 || rows >= this.row || cols < 0 || cols >= this.column){
            throw new IndexOutOfBoundsException("Invalid row or column");
        }
        return data[rows][cols]; 
    }

    public void SetElement(int rows, int cols, double value ){
        if(rows < 0 || rows >= this.row || cols < 0 || cols >= this.column){
            throw new IndexOutOfBoundsException("Invalid row or column");
        }
        this.data[rows][cols] = value;
    }

    /*
     * For two matrices to be added the numbers of rows and columns must match
     * the sum of the two data points that share the same place in the matrix equals the new point
     * loop through the whole matrix and return the new one 
     */
    public Matrix AddMatrix(Matrix that){
        if(this.row != that.row || this.column != that.column){
            throw new IllegalArgumentException("Matrices must have same dimensions for Addition please try again."); 
        }

        Matrix result = new Matrix(this.row, this.column); 
        for(int i = 0; i < this.row; i++){
            for(int j = 0; j < this.column; j++){
                result.data[i][j] = this.data[i][j] + that.data[i][j];
            }
        }

        return result; 
    }

    /*
     * the number of columns in A must match the number of rows in B 
     * A (mxn) x B (nxp) = AB (mxp)
     * the points that share the same index in the row in matrix A are multiplied by those in B f.ex. 
     *  2x3                3x3
     * |1 2 3|           |7 8 9| 
     * |4 5 6|           |1 2 3|
     *                   |4 5 6|
     * 
     * AB[0][0] = (1*7) + (2*1) + (3*4)
     * AB[0][1] = (1*8) + (2*2) + (3*5)
     * AB[0][2] = (1*9) + (2*3) + (3*6)
     * 
     * just like adding multiplied by the number of columns
     */
    public Matrix MultuplyMatrix(Matrix that){
        if(this.column != that.row){
            throw new IllegalArgumentException("Number of columns in Matrix A must match number of rows in Matrix B");
        }
        Matrix result = new Matrix(this.row, this.column); 
        for(int i = 0; i < this.row; i++){
            
            for(int j = 0; j < this.column; j++){
                double sum = 0; 
                for(int k = 0; k < this.column; k++){
                    sum += this.data[i][k] * that.data[k][j]; 
                }
                result.SetElement(i, j, sum);
            }
        }


        return result;
    }

    /**
     * Returns a string representation of the matrix
     * @return String showing matrix contents
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < this.row; i++) {
            sb.append("[");
            for (int j = 0; j < this.column; j++) {
                sb.append(String.format(" %6.2f ", this.data[i][j]));
            }
            sb.append("]\n");
        }
        return sb.toString();
        
    }



    public static void main(String[] args) {
        // Create two 2x2 matrices
        Matrix m1 = new Matrix(2, 2);
        Matrix m2 = new Matrix(2, 2);

        // Set values for m1
        m1.SetElement(0, 0, 1);
        m1.SetElement(0, 1, 2);
        m1.SetElement(1, 0, 3);
        m1.SetElement(1, 1, 4);

        // Set values for m2
        m2.SetElement(0, 0, 5);
        m2.SetElement(0, 1, 6);
        m2.SetElement(1, 0, 7);
        m2.SetElement(1, 1, 8);

        System.out.println("Matrix 1:");
        System.out.println(m1);

        System.out.println("Matrix 2:");
        System.out.println(m2);

        System.out.println("Matrix 1 + Matrix 2:");
        System.out.println(m1.AddMatrix(m2));

        System.out.println("Matrix 1 * Matrix 2:");
        System.out.println(m1.MultuplyMatrix(m2));
    }
}