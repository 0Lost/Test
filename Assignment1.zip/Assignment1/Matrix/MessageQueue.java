/**
    A first-in, first-out bounded collection of messages.
*/
public class MessageQueue
{
    
   private Message[] elements;
   private int head;
   private int tail;
   private int count;


   /**
       Constructs an empty message queue.
       @param capacity the maximum capacity of the queue
       @precondition capacity > 0;
   */
   public MessageQueue(int capacity)
   {

        assert capacity > 0 : "Precondition failed: capacity must be larger than 0 or an integer";

      elements = new Message[capacity];
      count = 0;
      head = 0;
      tail = 0;
   }

   /**
       Remove message at head.
       @return the message that has been removed from the queue
       @precondition size() > 0;
   */
   public Message removeFirst() 
   {

    assert size() > 0 : "Precondition failed: Queue is empty";

      Message r = elements[head];
      head = (head + 1) % elements.length;
      count--;
      return r;
   }

   /**
       Append a message at tail.
       @param aMessage the message to be appended
       @precondition size() < getCapacity();
   */
   public void add(Message aMessage)
   {
    
    assert this.size() < this.getCapacity() : "Precondition failed: size must be less than capacity to add a new element";


      elements[tail] = aMessage;
      tail = (tail + 1) % elements.length;
      count++;
   }

    // multiAdd(m1,m2,...,mn)

    public void multAdd(Message... messageVarargs){

        while (count + messageVarargs.length > elements.length){
            expandCapacity();
        }

        for(Message message : messageVarargs){    
            add(message);
        }
    }

    public Message[] multRemove(int n){

        if(n <= count){
            Message[] tempArr = new Message[n];
            for(int i = 0; i  < n; i++){
                tempArr[i] = removeFirst();
            }
            return tempArr; 
        }else{
            throw new IndexOutOfBoundsException("out of bounds - There are not ");
        }


    }


   /**
       Get the total number of messages in the queue.
       @return the total number of messages in the queue
   */
   public int size()
   {
      return count;
   }

   /**
       Get the maximum number of messages in the queue.
       @return the capacity of the queue
   */
   public int getCapacity()
   {
      return elements.length;
   }


   /**
       Get message at head.
       @return the message that is at the head of the queue
       @precondition size() > 0
   */
   public Message getFirst()
   {
        assert size() > 0 :  "Precondition failed: The stack is empty";
        return elements[head];
   }

    // 
    public void expandCapacity(){

       Message[] tempArr = new Message[elements.length * 2];

       for(int i = 0; i < elements.length; i++){
        tempArr[i] = elements[(head + i) % elements.length]; 
       }
        elements = tempArr;
        head = 0; 
        tail = count; 
    }


    public static void main(String[] args) {
        // Create a queue with a capacity of 5
        MessageQueue queue = new MessageQueue(5);
        
        // Add some messages to the queue
        System.out.println("Adding messages...");
        Message m1 = new Message("Message 1");
        Message m2 = new Message("Message 2");
        Message m3 = new Message("Message 3");
        Message m4 = new Message("Message 4");
        Message m5 = new Message("Message 5");

        queue.add(m1);
        queue.add(m2);
        queue.add(m3);
        queue.add(m4);
        queue.add(m5);

        // Display queue size after adding 5 messages
        System.out.println("Queue size after adding 5 messages: " + queue.size());

        // Try adding a 6th message (this should trigger an expansion)
        Message m6 = new Message("Message 6");
        queue.add(m6);
        System.out.println("Queue size after expanding and adding 6th message: " + queue.size());

        // Remove the first message from the queue
        System.out.println("Removing first message: " + queue.removeFirst().toString());
        System.out.println("Queue size after removing one message: " + queue.size());

        // Use multAdd to add multiple messages at once
        System.out.println("Using multAdd to add multiple messages...");
        Message m7 = new Message("Message 7");
        Message m8 = new Message("Message 8");
        queue.multAdd(m7, m8);
        System.out.println("Queue size after multAdd: " + queue.size());

        // Use multRemove to remove multiple messages
        System.out.println("Using multRemove to remove 3 messages...");
        Message[] removedMessages = queue.multRemove(3);
        for (Message msg : removedMessages) {
            System.out.println("Removed: " + msg.toString());
        }
        System.out.println("Queue size after multRemove: " + queue.size());

        // Try to remove more messages than are available (this should throw an exception)
        try {
            queue.multRemove(10);  // Attempt to remove 10 messages (more than the current size)
        } catch (IndexOutOfBoundsException e) {
            System.out.println("Caught exception: " + e.getMessage());
        }

        // Final queue size
        System.out.println("Final queue size: " + queue.size());
    }
}