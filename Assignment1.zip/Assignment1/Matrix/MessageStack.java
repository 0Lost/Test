public class MessageStack {
    private int capacity;
    private int top;
    private Message[] messages;

    public MessageStack(int size) {
        this.capacity = size;
        this.messages = new Message[capacity];
        this.top = -1;
    }

    public int size() {
        return top + 1;
    }

    public int getCapacity() {
        return capacity;
    }

    public boolean isEmpty() {
        return top == -1;
    }

    public Message pop() {
        if (isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        return messages[top--];
    }

    public void push(Message message) {
        if (top >= capacity - 1) {
            throw new IllegalStateException("Stack is full");
        }
        messages[++top] = message;
    }

    public void push(int n, Message[] pushedMessages) {
        if (top + n >= capacity) {
            throw new IllegalStateException("Not enough space to push all messages");
        }
        for (int i = 0; i < n; i++) {
            messages[++top] = pushedMessages[i];
        }
    }

    public Message[] pop(int n) {
        if (n > size()) {
            throw new IllegalStateException("Not enough messages to pop");
        }
        Message[] popped = new Message[n];
        for (int i = 0; i < n; i++) {
            popped[i] = pop();
        }
        return popped;
    }

    public Message peek() {
        if (isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        return messages[top];
    }
}
