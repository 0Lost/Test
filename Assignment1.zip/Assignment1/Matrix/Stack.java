public class Stack {
    private int capacity;  
    private int top;
    private int[] intArr;

    public Stack(int size) {
        this.capacity = size;
        this.intArr = new int[capacity];
        this.top = -1;  
    }

    public int getCurrentSize() {  
        return top + 1;
    }

    public int getCapacity() {
        return capacity;
    }

    public int pop() {
        if(isEmpty()) {
            throw new IllegalStateException("Stack is Empty");
        }
        return intArr[top--];
    }

    public void push(int value) {
        if(top >= capacity - 1) {
            throw new IllegalStateException("Stack is Full");
        }
        intArr[++top] = value;  // Fixed: Single increment
    }

    public boolean isEmpty() {
        return top == -1;
    }

    public int getTop() {
        if(isEmpty()) {
            throw new IllegalStateException("Stack is Empty");
        }
        return intArr[top];
    }

    public void Push(int nElements, int[] pushedEl){

        for(int i = 0; i < nElements;i++){
            intArr[++top] = pushedEl[i]; 
        }

    }

    public int[] Pop(int n)  {
        int[] tempArr = new int[n];

        for(int i = 0; i < n; i++){
            tempArr[i] = pop();
        }
        return tempArr;
    }

    public static void main(String[] args) {
        // Test 1: Initialize stack and check initial state
        Stack stack = new Stack(10);
        System.out.println("Test 1 - New Stack:");
        printStackStatus(stack);
        
        // Test 2: Push elements and check state
        System.out.println("\nTest 2 - Pushing elements:");
        for (int i = 1; i <= 5; i++) {
            stack.push(i);
            System.out.println("Pushed: " + i);
            printStackStatus(stack);
        }
        
        // Test 3: Peek and check state
        System.out.println("\nTest 3 - Peeking:");
        System.out.println("Top element: " + stack.getTop());
        printStackStatus(stack);
        
        // Test 4: Pop elements and check state
        System.out.println("\nTest 4 - Popping elements:");
        while (!stack.isEmpty()) {
            System.out.println("Popped: " + stack.pop());
            printStackStatus(stack);
        }
        
        // Test 5: Attempt operations on empty stack
        System.out.println("\nTest 5 - Empty stack operations:");
        try {
            stack.pop();
        } catch (IllegalStateException e) {
            System.out.println("Caught exception when popping: " + e.getMessage());
        }
        
        try {
            stack.getTop();
        } catch (IllegalStateException e) {
            System.out.println("Caught exception when peeking: " + e.getMessage());
        }
        
        printStackStatus(stack);
        
        // Test 6: Push after emptying
        System.out.println("\nTest 6 - Push after emptying:");
        stack.push(10);
        System.out.println("Pushed: 10");
        printStackStatus(stack);
    }
    
    private static void printStackStatus(Stack stack) {
        System.out.println("Stack Status:");
        System.out.println("  isEmpty(): " + stack.isEmpty());
        System.out.println("  Current size: " + stack.getCurrentSize());
        System.out.println("  Capacity: " + stack.getCapacity());
        System.out.println("  Top index: " + (stack.isEmpty() ? "N/A" : stack.top));
        System.out.println("  Top value: " + (stack.isEmpty() ? "N/A" : stack.getTop()));
        System.out.println("----------------------------------");
    }
}