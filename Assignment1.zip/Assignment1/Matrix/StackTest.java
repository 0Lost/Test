import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


public class StackTest {

    private Stack myStack;



    @BeforeEach
    void setUp() {
        myStack = new Stack(10);
    }

    @Test
    void testPush() {
        myStack.push(10);
        Assert.assertEquals(10, myStack.getTop());
    }

    @Test
    void testPop() {
        myStack.push(10);
        int popped = myStack.pop();
        Assert.assertEquals(10, popped);
    }

    @Test
    void testBulkPop() {
        int[] valuesToPush = {20, 30, 40};
        myStack.Push(valuesToPush.length, valuesToPush);

        int[] poppedValues = myStack.Pop(3);
        Assert.assertArrayEquals(new int[]{40, 30, 20}, poppedValues);
    }

    @Test
    void testBulkPush() {
        int[] pushedValues = {50, 60, 70};
        myStack.Push(pushedValues.length, pushedValues);
        Assert.assertEquals(70, myStack.getTop());
    }
}
