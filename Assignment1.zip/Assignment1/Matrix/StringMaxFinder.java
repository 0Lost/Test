import java.util.ArrayList;
import java.util.Comparator;

public class StringMaxFinder {
    
    // Method to find the largest string using a comparator

    public static String maximum(ArrayList<String> a ,Comparator<String> c ){

        if(a == null || a.isEmpty()) return null; 

        String max = a.get(0); 
        for(int i = 1; i < a.size(); i++){
            if(c.compare(a.get(i), max) > 0){
                max = a.get(i);
            }
        }

        return max;
    }


    // Test program 

    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList<>();
        list.add("apple");
        list.add("banana");
        list.add("kiwi");
        list.add("strawberry");

        // Comparator to find the longest string
        Comparator<String> lengthComparator = new Comparator<String>() {
            @Override
            public int compare(String s1, String s2) {
                return Integer.compare(s1.length(), s2.length());
            }
        };

        String longest = maximum(list, lengthComparator);
        System.out.println("The longest string is: " + longest);
    }

}
