package lecture5;

import javax.swing.*;
import java.awt.event.*;

public class Signal {
	private final int SAMPLING = 1000;
	
	public Signal(JTextArea jta) {
		Timer t = new Timer(SAMPLING, new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double amplitude = Math.random() * 10;
				jta.append(""+String.format("%.6f", amplitude)+"\n");
				for(int i=0;i<(int)amplitude;i++)
					System.out.print('*');
				System.out.println();
				// inform another view 
			}
		});
		t.start();
	}
	
}