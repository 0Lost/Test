package lecture5;

public class TestSignal {

	public static void main(String[] args) {
		SignalWindow window = new SignalWindow();
		new Signal(window.getTextArea());
	}

}
