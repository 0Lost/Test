package lecture5.observer;

public interface SignalObserver {
	public void updateSignal(double value);
}
