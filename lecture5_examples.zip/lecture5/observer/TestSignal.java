package lecture5.observer;

public class TestSignal {

	public static void main(String[] args) {
		// SignalWindow window = new SignalWindow();
		Signal s = new Signal();
		s.addSignalObserver(new SignalWindow());
		s.addSignalObserver(new PrintStarsObserver());
	}

}
