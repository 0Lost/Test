package lecture5.strategy;

public interface Sampler {
	public double read();
}
